// ours
#include <morpheus/overloaded.hpp>
#include <morpheus/osg_crawler.hpp>

// thirdparty

#include <CLI11.hpp>
#include <spdlog/fmt/fmt.h>
#include <spdlog/fmt/ostr.h>

#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/fruchterman_reingold.hpp>
#include <boost/graph/random_layout.hpp>
#include <boost/graph/point_traits.hpp>
#include <boost/graph/graphml.hpp>

#include <osg/Geode>
#include <osg/ShapeDrawable>
#include <osgViewer/Viewer>
// #include <osgViewer/ViewerEventHandlers>
// #include <osg/LightSource>

// std
#include <fstream>
#include <cmath>

using namespace boost;

void  draw_edge(osg::Vec3 start, osg::Vec3 end, float radius, osg::Vec4 color, osg::Group* owner)  {
    osg::Vec3 center;
    float height;

   osg::ref_ptr<osg::Cylinder> cylinder;
   osg::ref_ptr<osg::ShapeDrawable> cylinderDrawable;

   height = (start- end).length();
   center = osg::Vec3( (start.x() + end.x()) / 2,  (start.y() + end.y()) / 2,  (start.z() + end.z()) / 2);

   // This is the default direction for the cylinders to face in OpenGL
   osg::Vec3   z = osg::Vec3(0,0,1);

   // Get diff between two points you want cylinder along
   osg::Vec3 p = (start - end);

   // Get CROSS product (the axis of rotation)
   osg::Vec3   t = z ^  p;

   // Get angle. length is magnitude of the vector
   double angle = acos( (z * p) / p.length());

   //   Create a cylinder between the two points with the given radius
   cylinder = new osg::Cylinder(center,radius,height);
   cylinder->setRotation(osg::Quat(angle, osg::Vec3(t.x(), t.y(), t.z())));

   cylinderDrawable = new osg::ShapeDrawable(cylinder );
   cylinderDrawable->setColor(color);

   //   Add the cylinder between the two points to an existing group
   owner->addChild(cylinderDrawable);
}

int main(int argc, char* argv[]) {
    CLI::App app{"morpheus visualization crawler"};
    std::string llevel;
    std::string address;
    uint16_t port;
    double scale;

    app.add_option("--loglevel", llevel, "log verbosity (trace, debug, info, warn, error, critical, off)")->default_val("info");
    app.add_option("--address", address, "address to connect")->default_val("127.0.0.1");
    app.add_option("--port", port, "port to connect")->default_val("6161");
    app.add_option("--scale", scale, "scale of layout topology")->default_val("100");

    CLI11_PARSE(app, argc, argv);

    auto loglevel = spdlog::level::from_str(llevel);
    auto log = morpheus::make_log("main", spdlog::level::debug);
    asio::io_service io;
    std::optional<morpheus::social_graph> oosg;
    morpheus::osg_crawler crawler(io, address, port, loglevel);
    crawler.async_extract([&](const morpheus::osg_crawler::result& res) {
        std::visit(morpheus::overloaded{
            [&](const morpheus::social_graph& g) {
                log->info("extractor completed, commencing visualization");
                oosg.emplace(g);
            },
            [&](const std::error_code& ec) {
                log->error("extractor failed with {}", ec.message());
            }
        }, res);
    });
    io.run();

    if (oosg) {
        auto& osg = *oosg;
        using top = sphere_topology<>;
        top topology(200);
        random_graph_layout(osg, get(vertex_position, osg), topology);


        log->info("generating layout");
#if 0
        std::vector<top::point_difference_type> displacements(num_vertices(osg));
        fruchterman_reingold_force_directed_layout(osg, get(vertex_position, osg), topology,
                                                   square_distance_attractive_force(), square_distance_repulsive_force(),
                                                   all_force_pairs(), linear_cooling<double>(200),
                                                   make_iterator_property_map(displacements.begin(), get(vertex_index, osg), top::point_difference_type()));
#endif
        // export to graphml
        boost::dynamic_properties dp;

        std::ofstream fout("export.graphml");
        boost::write_graphml(fout, osg, dp, true);

        // construct the viewer.
        osgViewer::Viewer viewer;
        double node_alpha = 0.8;
        double edge_alpha = 0.1;       

        osg::ref_ptr<osg::Geode> root = new osg::Geode;
        auto position = get(vertex_position, osg);

        auto [vi, vi_end] = vertices(osg);
        size_t nvertices = std::distance(vi, vi_end);
        log->info("processing {} vertices", nvertices);
        for (; vi != vi_end; ++vi) {
            osg::ref_ptr<osg::ShapeDrawable> shape = new osg::ShapeDrawable;
            auto [in_begin, in_end] = boost::in_edges(*vi, osg);
            size_t nin = std::distance(in_begin, in_end);
            float g = std::min(std::log1p(2*nin)/std::log(256), 1.0);

            auto clr = osg::Vec4(1.0f, 1.0 - g, 0.0f, node_alpha);

            auto pos = osg::Vec3(position[*vi][0], position[*vi][1], position[*vi][2]);
            auto radius = 0.03f * scale;
            shape->setShape(new osg::Sphere(pos, radius));
            shape->setColor(clr);
            root->addChild(shape);
        }

        auto [ei, ei_end] = edges(osg);
        log->info("processing {} edges", std::distance(ei, ei_end));
        for (; ei != ei_end; ++ei) {
            auto source = boost::source(*ei, osg);
            auto source_pos = osg::Vec3(position[source][0], position[source][1], position[source][2]);
            auto target = boost::target(*ei, osg);
            auto target_pos = osg::Vec3(position[target][0], position[target][1], position[target][2]);
            auto radius = 0.003f * scale;
            auto blue = osg::Vec4(0.0f, 1.0f, 0.0f, edge_alpha);
            draw_edge(source_pos, target_pos, radius, blue, root.get());
        }

        log->info("starting visualization");
        viewer.setSceneData(root.get());
        return viewer.run();
    }
    return -1;
}



