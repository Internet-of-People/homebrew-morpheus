#define CATCH_CONFIG_MAIN

// ours
#include <morpheus/osg/service.hpp>
#include <morpheus/logger.hpp>
#include <morpheus/proto.hpp>

// thirdparty
#include <catch.hpp>
#include <rocksdb/db.h>
#include <spdlog/fmt/fmt.h>
#include <spdlog/fmt/ostr.h>
#include <msgpack.hpp>


// std
#include <string>
#include <vector>
#include <random>
#include <climits>
#include <algorithm>
#include <functional>

using namespace morpheus::osg;


TEST_CASE("noop", "[smoke]") {
    REQUIRE(true);
}

const std::string default_db_path = "/tmp/testdb";
void reset_db(const std::string& db_path = default_db_path) {
    system(fmt::format("rm -rf {}", db_path).c_str());
}

TEST_CASE("db_creation", "") {
    reset_db();
    rocksdb::DB* db;
    rocksdb::Options options;
    options.create_if_missing = true;
    rocksdb::Status status = rocksdb::DB::Open(options, default_db_path, &db);
    REQUIRE(status.ok());
    delete db;
}

TEST_CASE("db_creation_fail", "") {
    reset_db();
    rocksdb::DB* db;
    rocksdb::Options options;
    options.create_if_missing = false;
    rocksdb::Status status = rocksdb::DB::Open(options, default_db_path, &db);
    REQUIRE(status != rocksdb::Status::OK());
    delete  db;
}

struct serialize_me {
    serialize_me() :
        number(0),
        text("")
    {}

    serialize_me(int number, const std::string& text) :
        number(number),
        text(text)
    {}

    bool operator==(const serialize_me& other) const {
        return number == other.number && text == other.text;
    }


    int number;
    std::string text;

    MSGPACK_DEFINE_MAP(number, text);
};


TEST_CASE("simple roundtrip", "[msgpack]") {
    serialize_me reference(42, "foobar");

    std::stringstream ss;
    msgpack::pack(ss, reference);

    msgpack::object_handle oh = msgpack::unpack(ss.str().data(), ss.str().size());
    serialize_me degraded = oh.get().as<serialize_me>();

    REQUIRE(reference == degraded);
}


TEST_CASE("simple roundtrip, reversing field order", "[msgpack]") {
    std::stringstream ss_ref;
    std::stringstream ss_deg;
    msgpack::packer p_ref(ss_ref);
    msgpack::packer p_deg(ss_deg);

    std::string number_field = "number";
    std::string text_field = "text";
    int number = 42;
    std::string text = "forty-two";

    // reference
    p_ref.pack_map(2);

    p_ref.pack_str(text_field.size());
    p_ref.pack_str_body(text_field.c_str(), text_field.size());

    p_ref.pack_str(text.size());
    p_ref.pack_str_body(text.c_str(), text.size());

    p_ref.pack_str(number_field.size());
    p_ref.pack_str_body(number_field.c_str(), number_field.size());

    p_ref.pack_int32(number);

    msgpack::object_handle oh = msgpack::unpack(ss_ref.str().data(), ss_ref.str().size());
    serialize_me reference = oh.get().as<serialize_me>();

    // degraded
    p_deg.pack_map(2);

    p_deg.pack_str(number_field.size());
    p_deg.pack_str_body(number_field.c_str(), number_field.size());

    p_deg.pack_int32(number);

    p_deg.pack_str(text_field.size());
    p_deg.pack_str_body(text_field.c_str(), text_field.size());

    p_deg.pack_str(text.size());
    p_deg.pack_str_body(text.c_str(), text.size());

    msgpack::object_handle oh_deg = msgpack::unpack(ss_deg.str().data(), ss_deg.str().size());
    serialize_me degraded = oh_deg.get().as<serialize_me>();

    REQUIRE(degraded == reference);
    REQUIRE(degraded.number == number);
    REQUIRE(degraded.text == text);
}


TEST_CASE("dummy mux with osg") {
    reset_db();
    static bool send_called = false;
    struct dummy_mux {
        morpheus::service_id name() const {
            return "dummy";
        }

        void send(const morpheus::message& msg) {
            send_called = true;
            REQUIRE(msg.target == "osg");
        }
    };

    auto mux = std::make_shared<dummy_mux>();
    auto svc = std::make_shared<morpheus::osg::service<dummy_mux>>(default_db_path, morpheus::log_level::info);
    auto handler = svc->attach(mux);

    morpheus::osg::proto::node_id profile_id = {0xDE, 0xAD, 0xBE, 0xEF};
    morpheus::osg::proto::add_node inner;
    inner.id = profile_id;
    morpheus::osg::proto::request req{0, inner};

    morpheus::message msg;
    msg.target = "osg";
    morpheus::msgp::vector_buffer_adapter buffer(msg.payload);
    msgpack::pack(buffer, req);

    handler->on_message(msg);
    REQUIRE(send_called);
}

TEST_CASE("standalone service") {
    using namespace morpheus;
    reset_db();
    struct null_mux {
        std::string name() const {
            return "null";
        }

        void send(const message& msg) {
            REQUIRE(msg.target == "osg");
        }
    };

    osg::service<null_mux> svc(default_db_path, log_level::info);
    osg::proto::node_id profile_id1 = {0xDE, 0xAD, 0xBE, 0xEF};
    osg::proto::node_id profile_id2 = {0xDE, 0xAD, 0xFA, 0xCE};

    std::visit( overloaded{
        [](const std::vector<morpheus::osg::proto::node_id> &nodes)
            { REQUIRE(nodes.size() == 0); },
        [](const auto &) { FAIL(); }
    }, svc.list_nodes() );

    REQUIRE(svc.add_node(profile_id1).code == osg::proto::error_code::ok);
    REQUIRE(svc.add_node(profile_id2).code == osg::proto::error_code::ok);

    std::visit( overloaded{
        [](const std::vector<morpheus::osg::proto::node_id> &nodes)
            { REQUIRE(nodes.size() == 2); },
        [](const auto &) { FAIL(); }
    }, svc.list_nodes() );

    REQUIRE(svc.add_edge(profile_id1, profile_id2).code == osg::proto::error_code::ok);

    std::visit( overloaded{
        [](const std::vector<morpheus::osg::proto::node_id> &nodes)
            { REQUIRE(nodes.size() == 1); },
        [](const auto &) { FAIL(); }
    }, svc.list_outedges(profile_id1) );
    std::visit( overloaded{
        [](const std::vector<morpheus::osg::proto::node_id> &nodes)
            { REQUIRE(nodes.size() == 1); },
        [](const auto &) { FAIL(); }
    }, svc.list_inedges(profile_id2) );

    REQUIRE(svc.remove_node(profile_id1).code == osg::proto::error_code::ok);
    // NOTE remove_node should already cascade deletes edges
    // REQUIRE(svc.remove_edge(profile_id1, profile_id2).code == osg::proto::error_code::ok);

    std::visit( overloaded{
        [](const std::vector<morpheus::osg::proto::node_id> &nodes)
            { REQUIRE(nodes.size() == 1); },
        [](const auto &) { FAIL(); }
    }, svc.list_nodes() );
    std::visit( overloaded{
        [](const std::vector<morpheus::osg::proto::node_id> &) { FAIL();},
        [](const auto &err) { REQUIRE(err.code == osg::proto::error_code::key_not_found); }
    }, svc.list_outedges(profile_id1) );
    std::visit( overloaded{
        [](const std::vector<morpheus::osg::proto::node_id> &nodes)
            { REQUIRE(nodes.size() == 0); },
        [](const auto &) { FAIL(); }
    }, svc.list_inedges(profile_id2) );

    REQUIRE(svc.remove_node(profile_id2).code == osg::proto::error_code::ok);

    std::visit( overloaded{
        [](const std::vector<morpheus::osg::proto::node_id> &nodes)
            { REQUIRE(nodes.size() == 0); },
        [](const auto &) { FAIL(); }
    }, svc.list_nodes() );
}


std::vector<uint8_t> random_profile() {
    using random_bytes_engine = std::independent_bits_engine<std::default_random_engine, CHAR_BIT, uint8_t>;

    static random_bytes_engine rbe;
    static const size_t profile_size = 32;
    std::vector<unsigned char> retval(profile_size);
    std::generate(retval.begin(), retval.end(), std::ref(rbe));
    return retval;
}


TEST_CASE("influencers_followers") {
    using namespace morpheus;
    reset_db();
    struct null_mux {
        std::string name() const {
            return "null";
        }

        void send(const message& msg) {
            REQUIRE(msg.target == "osg");
        }
    };

    osg::service<null_mux> svc(default_db_path, log_level::info);

    size_t ninfluencers = 7;
    std::deque<std::vector<uint8_t>> influencers(ninfluencers);
    std::generate(influencers.begin(), influencers.end(), random_profile);
    for(auto&& p : influencers) {
        svc.add_node(p);
    }

    size_t nfollowers = 75;
    std::deque<std::vector<uint8_t>> followers(nfollowers);
    std::generate(followers.begin(), followers.end(), random_profile);
    for(auto&& p : followers) {
        svc.add_node(p);
    }


    std::random_device rd;
    std::mt19937 g(rd());

    for(auto&& f : followers) {
        std::shuffle(influencers.begin(), influencers.end(), g);
        size_t nfollows = 2;
        for(auto iit = influencers.begin(); iit != influencers.begin() + nfollows; ++iit) {
            svc.add_edge(f, *iit);
        }
    }


}

