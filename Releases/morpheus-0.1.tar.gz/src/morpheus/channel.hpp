#pragma once

// thirdparty
#include <asio/io_service.hpp>
#include <asio/io_service_strand.hpp>

// std
#include <variant>
#include <system_error>
#include <deque>

namespace morpheus {

///
/// \brief The channel template
///
/// A bounded queue (multiple producer/multiple consumer) for properly implementing flow control via back pressure
/// in the morpheus messaging architecture.
///
/// Just a concept scratch there are many things to work out here:
///  - threading model/callback contexts (eventually writers want to receive their callback in foreign threads
///  - multiple producer/single consumer might be enough
///
template<typename T>
class channel {
public:
    channel(asio::io_service& io, size_t capacity) :
        io(io),
        strand(io),
        capacity(capacity)
    {}

    using write_completion_handler = std::function<void(const std::error_code& ec)>;
    using read_completion_handler = std::function<void(std::variant<std::error_code, T>)>;

    template<typename Executor>
    void async_write(T item, Executor e, write_completion_handler cb) {
        strand.post([this, item{std::move(item)}, cb{std::move(cb)}] {
            if (!outqueue.empty()) {
                auto cb2 = outqueue.front();
                outqueue.pop_front();
                io.post(std::bind(cb2, std::move(item)));
                return io.post(std::bind(cb, std::error_code{}));
            }

            if (items.size() < capacity) {
                items.push_back(std::move(item));
                return io.post(std::bind(cb, std::error_code{}));
            }

            inqueue.emplace_back(std::move(cb), std::move(item));
        });
    }

    template<typename Executor>
    void async_read(Executor e, read_completion_handler cb) {
        strand.post([this, cb{std::move(cb)}] {
            if (items.empty()) {
                if (inqueue.empty()) {
                    // no data available
                    return outqueue.push_back(std::move(cb));
                }

                auto in = inqueue.front();
                inqueue.pop_front();
                io.post(in.cb, std::error_code{});
                io.post(cb, std::move(in.item));
                return;
            }

            io.post(cb, std::move(items.front()));
            items.pop_front();

            // drain items from incoming
            if (items.size() < capacity && !inqueue.empty()) {
                items.push_back(std::move(inqueue.front().item));
                io.post(std::bind(inqueue.front().cb, std::error_code{}));
                inqueue.pop_front();
            }
        });
    }
private:
    struct incoming {
        incoming(write_completion_handler cb, T item) :
            cb(cb),
            item(std::move(item))
        {}

        write_completion_handler    cb;
        T                           item;
    };


private:
    asio::io_service&                       io;
    asio::io_service::strand                strand;
    size_t                                  capacity;

    std::deque<T>                           items;
    std::deque<incoming>                    inqueue;
    std::deque<read_completion_handler>     outqueue;
};


} // namespace morpheus
