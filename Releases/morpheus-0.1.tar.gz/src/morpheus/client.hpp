#pragma once

// ours
#include <morpheus/proto.hpp>
#include <morpheus/message.hpp>
#include <morpheus/msgpack_helpers.hpp>
#include <morpheus/logger.hpp>

// thirdparty
#include <asio/io_service.hpp>
#include <asio/write.hpp>
#include <asio/read.hpp>


// std
#include <system_error>
#include <string>
#include <optional>
#include <variant>

namespace morpheus {

template<typename Stream>
class client {
public:
    using response = std::variant<std::error_code, std::vector<uint8_t>>;
    using completion_handler = std::function<void(const response&)>;


    client(asio::io_service& io, Stream& stream, log_level verbosity) :
        io(io),
        stream(stream),
        log(make_log("client", verbosity))
    {}

    template<typename Request>
    void async_request(service_id svc, const Request& req, completion_handler cb) {
        if (pending) {
            post(cb, make_error_code(std::errc::operation_in_progress));
        }

        pending.emplace(svc, req, cb);
        start_send();
    }

private:
    void post(completion_handler cb, const response& resp) {
        io.post(std::bind(cb, resp));
    }

    void complete(const response& resp) {
        if (auto req = std::exchange(pending, std::nullopt)) {
            post(req->cb, resp);
        }
    }

    void start_send() {
        asio::async_write(stream, asio::buffer(pending->data), [this] (const std::error_code& ec, size_t bytes_written) {
            if (ec) {
                return complete(ec);
            }

            log->debug("written {} bytes", bytes_written);
            start_read();
        });
    }

    void start_read() {
        static const size_t read_chunk_size = 1024;
        static const size_t max_message_size = 65536;
        rx_buffer.reserve_buffer(read_chunk_size);
        stream.async_read_some(asio::mutable_buffer(rx_buffer.buffer(), read_chunk_size), [this](const std::error_code& ec, size_t bytes_transferred) {
            if (ec) {
                return complete(ec);
            }

            log->debug("read {} bytes", bytes_transferred);
            rx_buffer.buffer_consumed(bytes_transferred);

            // bail out on too long messages
            if (rx_buffer.message_size() > max_message_size) {
                log->warn("message size overflow, actual: {} bytes, limit: {} bytes", rx_buffer.message_size(), max_message_size);
                return complete(make_error_code(std::errc::bad_message));
            }

            // parse process object
            msgpack::object_handle oh;
            try {
                if (rx_buffer.next(oh)) {
                   return complete(oh.get().as<message>().payload);
                }
            } catch (const std::exception& ex) {
                log->warn("message parse error: {}", ex.what());
                return complete(make_error_code(std::errc::bad_message));
            }

            start_read();
        });
    }
private:
    template<typename Request>
    static std::vector<uint8_t> msg2bytes(const service_id& svc, const Request& req) {
        std::vector<uint8_t> payload;
        msgp::vector_buffer_adapter buf(payload);
        msgpack::pack(buf, req);
        message msg{svc, payload};
        payload.clear();
        msgpack::pack(buf, msg);
        return payload;
    }

    struct pending_request {
        template<typename Request>
        pending_request(service_id svc, const Request& req, completion_handler cb) :
            data(msg2bytes(svc, req)),
            cb(cb)
        {}

        std::vector<uint8_t>    data;
        completion_handler      cb;
    };
private:
    asio::io_service&                   io;
    Stream&                             stream;
    std::optional<pending_request>      pending;
    msgpack::unpacker                   rx_buffer;
    log_handle                          log;
};


} // namespace morpheus
