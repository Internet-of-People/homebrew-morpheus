#pragma once

#include "rocksdb_helpers.hpp"

#include <rocksdb/db.h>

#include <string>
#include <vector>

namespace morpheus {

enum class column_family {
    nodes,
    edges,
};


class database {
public:

    static rocksdb::Options default_rw_options() {
        rocksdb::Options retval;
        retval.create_missing_column_families = true;
        retval.create_if_missing = true;
        return retval;
    }

    static rocksdb::Options default_ro_options() {
        rocksdb::Options retval;
        retval.create_missing_column_families = true;
        retval.create_if_missing = true;
        return retval;
    }


    database(const std::string& file_name, const rocksdb::Options& options = default_rw_options()) :
        cfnodes(nullptr),
        cfedges(nullptr)
    {
        rocksdb::DB* retval = nullptr;
        auto status = rocksdb::DB::Open(options, file_name, column_families(), &cfs, &retval);
        if (!status.ok()) {
            throw std::runtime_error(fmt::format("failed to open '{}': {}", file_name, status.ToString()));
        }

        for(auto&& cf : cfs) {
            auto cfname = cf->GetName();
            if (cfname == to_string(column_family::nodes)) {
                cfnodes = cf;
                continue;
            }
            if (cfname == to_string(column_family::edges)) {
                cfedges = cf;
                continue;
            }
        }

        db.reset(retval);
    }

    ~database() {
        for(auto&& cfh : cfs) {
            delete cfh;
        }
    }

    // basic load/store operations
    template<typename T, typename Q>
    void store(column_family cf, const T& key, const Q& value) {
        morpheus::rdb::store(connection(), get_column_family(cf), key, value);
    }

    template<typename T>
    std::optional<morpheus::rdb::value> load(column_family cf, const T& v) {
        return morpheus::rdb::load(connection(), get_column_family(cf), v);
    }

    template<typename T>
    void remove(column_family cf, const T& key) {
        morpheus::rdb::remove(connection(), get_column_family(cf), key);
    }

    rocksdb::ColumnFamilyHandle* operator[](column_family cf) const {
        return get_column_family(cf);
    }


    rocksdb::DB& connection() {
        return *db;
    }

private:

    rocksdb::ColumnFamilyHandle* get_column_family(column_family cf) const {
        switch(cf) {
            case column_family::nodes : return cfnodes;
            case column_family::edges : return cfedges;
            default:
                std::terminate();
        }
    }


    static std::string nodes_cf_name() {
        static const std::string retval = "nodes";
        return retval;
    }

    static std::string edges_cf_name() {
        static std::string retval = "edges";
        return retval;
    }

    static std::vector<std::string> column_family_names() {
        return {nodes_cf_name(), edges_cf_name(), rocksdb::kDefaultColumnFamilyName};
    }

    static std::string to_string(column_family cf) {
        switch(cf) {
            case column_family::nodes : return nodes_cf_name();
            case column_family::edges : return edges_cf_name();
            default:
                std::terminate();
        }
    }

    static std::vector<rocksdb::ColumnFamilyDescriptor> column_families() {
        std::vector<rocksdb::ColumnFamilyDescriptor> retval;
        for(auto&& name : column_family_names()) {
            retval.emplace_back(name, rocksdb::ColumnFamilyOptions());
        }

        return retval;
    }

private:
    rdb::db_handle                              db;
    std::vector<rocksdb::ColumnFamilyHandle*>   cfs;
    rocksdb::ColumnFamilyHandle*                cfnodes;
    rocksdb::ColumnFamilyHandle*                cfedges;
};


} // namespace morpheus
