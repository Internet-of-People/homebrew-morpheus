#pragma once

// ours
#include "proto.hpp"
#include <morpheus/message.hpp>

// thirdparty

// std
#include <string>

namespace morpheus {

///
/// Handler class is representing a pending session (~connection) on a given Multiplexer
/// handler instances are created on a new session for each registered session for a given Session
///
template<typename MUX>
class handler {
public:
    virtual ~handler() = default;

    ///
    /// \brief on_message method invoked on incoming messages after the envelope has been parsed and stripped off
    /// \param msg the message payload
    /// \return an error code, a non-success code means that the session containing the handler should be disconnected
    ///
    virtual std::error_code on_message(const message& msg) = 0;
protected:
    handler(const service_id& id, std::shared_ptr<MUX> owner) :
        id(id),
        owner(owner)
    {}

    template<typename T>
    void send_message(const T& msg) {
        if (auto o = owner.lock()) {
            o->send(to_message(id, msg));
        }
    }

private:
    service_id         id;
    std::weak_ptr<MUX> owner;
};

template<typename MUX>
using handler_ref = std::unique_ptr<handler<MUX>>;

} // namespace morpheus
