#pragma once

#include <spdlog/logger.h>
#include <spdlog/sinks/stdout_color_sinks.h>


namespace morpheus {

using log_handle = std::shared_ptr<spdlog::logger>;
using log_level = spdlog::level::level_enum;

inline
log_handle make_log(const std::string& name, log_level verbosity) {
    auto sink = std::make_shared<spdlog::sinks::stdout_color_sink_mt>();
    auto retval = std::make_shared<spdlog::logger>(name, sink);
    retval->set_level(verbosity);
    return retval;
}

} // morpheus
