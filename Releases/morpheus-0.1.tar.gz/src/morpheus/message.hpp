#pragma once

// ours
#include "proto.hpp"
#include "msgpack_helpers.hpp"

// thirdparty
#include <msgpack.hpp>
#include <spdlog/fmt/fmt.h>
#include <botan-2/botan/hex.h>

// std
#include <string>
#include <ostream>

namespace morpheus {
#define MSGPACK_INTRUSIVE_SERIALIZATION

struct message {
    std::string             target;
    std::vector<uint8_t>    payload;
#ifdef MSGPACK_INTRUSIVE_SERIALIZATION
    MSGPACK_DEFINE_MAP(target, payload);
#endif
};

inline
std::ostream& operator<<(std::ostream& lhs, const message& rhs) {
    return lhs << fmt::format("target: {}, payload: {}", rhs.target, Botan::hex_encode(rhs.payload));
}

template<typename T>
message to_message(const std::string& target, const T& payload) {
    return message{target, to_payload(payload)};
}

} // namespace morpheus


#ifndef MSGPACK_INTRUSIVE_SERIALIZATION
namespace msgpack {
MSGPACK_API_VERSION_NAMESPACE(MSGPACK_DEFAULT_API_NS) {
namespace adaptor {

template<>
struct convert<morpheus::message> {
    msgpack::object const& operator()(msgpack::object const& o, morpheus::message& v) const {
        if (o.type != msgpack::type::MAP) throw msgpack::parse_error("map expected");

        std::optional<std::string> target;
        std::optional<std::vector<std::uint8_t>> payload;

        for(decltype(o.via.map.size) idx = 0; idx < o.via.map.size; ++idx) {
            const msgpack::object_kv& kv = o.via.map.ptr[idx];
            if (morpheus::try_fetch_field("target", kv, target) ||
                morpheus::try_fetch_field("payload", kv, payload))
            {
                if (target && payload) {
                    v.target = *target;
                    v.payload = *payload;
                    return o;
                }
            }
        }

        throw msgpack::parse_error("target or payload is missing");
    }
};

template <>
struct object<morpheus::message> {
    void operator()(msgpack::object& obj, const morpheus::message& msg) const {
        // TODO:
    }
};


} // namespace adaptor
} // namespace MSGPACK_DEFAULT_API_NS
} // namespace msgpack


#endif
