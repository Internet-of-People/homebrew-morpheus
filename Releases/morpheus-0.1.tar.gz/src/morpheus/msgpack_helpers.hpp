#pragma once

// thirdparty
#include <spdlog/fmt/fmt.h>
#include <msgpack.hpp>

// std
#include <optional>
#include <string>

namespace morpheus {
namespace msgp {

template<typename T>
bool try_fetch_field(const std::string& field_name,
                     const ::msgpack::object_kv& kv,
                     std::optional<T>& target) {
    std::string key_str = kv.key.as<std::string>();

    if (field_name != key_str) {
        return false;
    }

    if (target) {
        throw ::msgpack::parse_error(fmt::format("duplicate '{}' field", field_name));
    }

    target = kv.val.as<T>();
    return true;
}

struct vector_buffer_adapter {
public:
    explicit vector_buffer_adapter(std::vector<uint8_t>& vec) :
        vec(vec)
    {}

    vector_buffer_adapter() = delete;
    vector_buffer_adapter(const vector_buffer_adapter& ) = delete;
    vector_buffer_adapter& operator=(const vector_buffer_adapter&) = delete;

    void write(const char* ptr, size_t size) {
        auto p = reinterpret_cast<const uint8_t*>(ptr);
        std::copy(p, p + size, std::back_inserter(vec));
    }
private:
    std::vector<uint8_t>& vec;
};

} // namespace msgpack
} // namespace morpheus

