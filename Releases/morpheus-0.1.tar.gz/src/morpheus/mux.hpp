#pragma once

// ours
#include "proto.hpp"
#include "logger.hpp"
#include "message.hpp"
#include "handler.hpp"

// thirdparty
#include <asio/write.hpp>
#include <asio/io_service.hpp>
#include <msgpack.hpp>

// std
#include <functional>
#include <optional>
#include <vector>

namespace morpheus {

///
/// \brief The mux class
///
/// This class is an implementation of the Multiplexer concept. It's built on top of a reliable channel (e.g. a connected tcp stream) and responsible
/// for
///  - maintaining a map of handlers (one handler per service per multiplexer)
///  - reading, deserializing and demultiplexing incoming messages
///  - serializing, queueing and sending outgoing messages
///
/// The Multiplexer concept boils down to the following operations
///
/// - async_wait(completion_handler) => wait for connection termination
/// - send(const message&)           => send a message for the remote peer
/// - cancel()                       => terminate the peer connection
/// - add_handler(handler_ref)       => register a message handler for incoming messages
///
/// TODO:
/// - It's entirely missing to separate the execution context of the mux and the corresponding handler (that would be a good place for parallelization)
/// - Flow control (now it's possible to blow up the server by overloading it) => here e.g. the Microsoft SMP protocol could be used
///
///
class mux {
public:
    using completion_handler = std::function<void(const std::error_code& ec)>;

    mux(session_id sid, socket&& sock, log_level verbosity) :
        io(sock.get_io_service()),
        tx(false),        
        sid(sid),
        sock(std::move(sock)),
        rx(false),
        log(make_log(name(), verbosity))
    {
        log->info("mux initialized for endpoint {}", this->sock.remote_endpoint());
    }

    std::string name() const {
        return fmt::format("mux#{}", sid);
    }

    void async_wait(completion_handler cb) {
        if (this->handler) {
            return post(cb, make_error_code(std::errc::operation_in_progress));
        }

        this->handler = cb;

        start_read();
    }

    void send(const message& msg) {
        tx_queue.emplace_back(msg);
        start_write();
    }

    void cancel() {
        sock.cancel();
    }

    void add_handler(service_id id, handler_ref<mux> h) {
        handlers.emplace(id, std::move(h));
    }

private:
    static size_t read_chunk_size() {
        return 64;
    }

    static size_t max_message_size() {
        return 512;
    }
private:
    void post(completion_handler handler, const std::error_code& ec) {
        io.post(std::bind(handler, ec));
    }

    void complete(const std::error_code& ec) {
        if (!result) {
            result = ec;
        }

        if (rx || tx) {
            return;
        }

        if (auto ocb = std::exchange(handler, std::nullopt)) {
            post(*ocb, *result);
        }
    }

    void start_write() {
        if (tx_queue.empty()) {
            // nothing to send
            return;
        }

        if (std::exchange(tx, true)) {
            // already sending
            return;
        }

        log->trace("transmitting message: {}", tx_queue.front());
        msgp::vector_buffer_adapter buf(tx_buf);
        msgpack::pack(buf, tx_queue.front());
        asio::async_write(sock, asio::buffer(tx_buf), [this](const std::error_code& ec, size_t bytes_transferred) {
            tx = false;
            tx_buf.clear();
            tx_queue.pop_front();
            log->trace("transmitted {} bytes", bytes_transferred);
            if (ec) {
                log->error("failed to write to socket: {} ({})", ec.message(), ec);
                return complete(ec);
            }

            start_write();
        });
    }

    void start_read() {
        rx_buffer.reserve_buffer(read_chunk_size());
        rx = true;
        sock.async_read_some(asio::mutable_buffer(rx_buffer.buffer(), read_chunk_size()), [this](const std::error_code& ec, size_t bytes_transferred) {
            rx = false;
            if (ec) {
                log->error("failed to read from socket: {} ({})", ec.message(), ec);
                return complete(ec);
            }

            rx_buffer.buffer_consumed(bytes_transferred);

            // start streaming deserialization.
            log->trace("read {} bytes, message size: {} bytes, parsed size: {} bytes, nonparsed_size: {} bytes", bytes_transferred, rx_buffer.message_size(), rx_buffer.parsed_size(), rx_buffer.nonparsed_size());

            // bail out on too long messages
            if (rx_buffer.message_size() > max_message_size()) {
                log->warn("message size overflow, actual: {} bytes, limit: {} bytes", rx_buffer.message_size(), max_message_size());
                return complete(make_error_code(std::errc::bad_message));
            }

            // parse process object
            msgpack::object_handle oh;
            try {
                while(rx_buffer.next(oh)) {
                    process_message(oh.get());
                }
            } catch (const std::exception& ex) {               
                log->warn("message parse error: {}", ex.what());
                return complete(make_error_code(std::errc::bad_message));
            }

            start_read();
        });
    }

    void process_message(const msgpack::object& obj) {
        //
        auto msg = obj.as<message>();
        if (auto it = handlers.find(msg.target); it != handlers.end()) {
            try {
                log->trace(">>> {}", msg);
                std::error_code ec = it->second->on_message(msg);
                if (ec) {
                    log->warn("{} handler returned: {} ({})", msg.target, ec, ec.message());
                    return complete(ec);
                }
            } catch (...) {
                log->error("{} handler failed");
                return complete(make_error_code(std::errc::protocol_error));
            }
        } else {
            log->warn("failed to look up handler for message {}", msg);
        }
    }
private:
    using handler_map = std::map<service_id, handler_ref<mux>>;
private:
    asio::io_service&                   io;
    std::optional<completion_handler>   handler;       // storing the callback after the mux has been activated via async_wait()
    std::optional<std::error_code>      result;        // storing the error_code for the mux for later delivery into the cb

    // outgoing stuff
    bool                                tx;             // true, if currently sending
    std::vector<uint8_t>                tx_buf;         // the value under sending
    std::deque<message>                 tx_queue;       // pending items

    session_id                          sid;
    socket                              sock;

    // incoming stuff
    bool                                rx;            // true, if currently reading
    msgpack::unpacker                   rx_buffer;     // read buffer



    handler_map                         handlers;
    log_handle                          log;
};

} // namespace morpheus
