#pragma once

// ours
#include "proto.hpp"
#include <morpheus/message.hpp>
#include <morpheus/handler.hpp>
#include <morpheus/overloaded.hpp>
#include <morpheus/logger.hpp>

// thirdparty

// std
#include <system_error>
#include <memory>


namespace morpheus {
namespace osg {

template<typename Service>
class handler : public morpheus::handler<typename Service::mux_type> {
public:
    using service_type = Service;
    using mux_type = typename Service::mux_type;

    handler(service_type& svc, std::shared_ptr<mux_type> m, log_level verbosity) :
        morpheus::handler<mux_type>(svc.id(), m),
        svc(svc),
        log(make_log(fmt::format("{}@{}", svc.id(), m->name()), verbosity))
    {}

    virtual std::error_code on_message(const message &msg) override {
        msgpack::object_handle oh = msgpack::unpack((char*)msg.payload.data(), msg.payload.size());
        try {
            process_message(oh.get().as<proto::request>());
            return std::error_code{};
        } catch (const std::system_error& ex) {
            log->error("failed to process message '{}': {}", oh.get(), ex.what());
            return ex.code();
        } catch (const std::exception& ex) {
            log->error("failed to process message '{}': {}", oh.get(), ex.what());
            return make_error_code(std::errc::invalid_argument);
        } catch (...) {
            log->error("failed to process message '{}'", oh.get());
            return make_error_code(std::errc::invalid_argument);
        }
    }

private:
    template<typename T>
    void send_response(const ::morpheus::osg::proto::response<T>& resp) {
        log->debug("<<< {}", resp);
        this->send_message(resp);
    }

    void reply(proto::request_id rid, const proto::result& res) {
        send_response(::morpheus::osg::proto::response<void>(rid,res));
    }

    template<typename T>
    void reply(proto::request_id rid, const std::variant<proto::result, T>& v) {
        std::visit(overloaded{
            [&](const proto::result& r) {
                send_response(proto::response<T>(rid, r.code, r.msg));
            },
            [&](const T& retval) {
                send_response(proto::response<T>(rid, retval));
            }
        }, v);
    }

    void process_message(const proto::request& req) {
        log->debug(">>> {}", req);        
        std::visit([&](const auto& inner) { reply(req.rid, inner(svc)); }, req.inner);
    }
private:
    Service&                    svc;
    log_handle                  log;
};


} // namespace morpheus
} // namespace osg
