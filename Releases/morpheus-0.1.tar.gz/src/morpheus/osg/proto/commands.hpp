#pragma once

#include "primitives.hpp"

#include <msgpack.hpp>
#include <botan-2/botan/hex.h>

#include <iostream>

namespace morpheus::osg::proto {

struct add_node {
    node_id id;
    MSGPACK_DEFINE_MAP(id);
    template<typename Service>
    auto operator()(Service& svc) const {
        return svc.add_node(id);
    }

    static std::string command_name() { return "add_node"; }
};

inline
std::ostream& operator<<(std::ostream& lhs, const add_node& rhs) {
    return lhs << fmt::format("add_node node_id: {}", Botan::hex_encode(rhs.id));
}


struct remove_node {
    node_id id;
    MSGPACK_DEFINE_MAP(id);
    template<typename Service>
    auto operator()(Service& svc) const {
        return svc.remove_node(id);
    }

    static std::string command_name() { return "remove_node"; }
};

inline
std::ostream& operator<<(std::ostream& lhs, const remove_node& rhs) {
    return lhs << fmt::format("remove_node node_id: {}", Botan::hex_encode(rhs.id));
}


struct add_edge {
    node_id source;
    node_id target;
    MSGPACK_DEFINE_MAP(source, target);

    template<typename Service>
    auto operator()(Service& svc) const {
        return svc.add_edge(source, target);
    }

    static std::string command_name() { return "add_edge"; }
};

inline
std::ostream& operator<<(std::ostream& lhs, const add_edge& rhs) {
    return lhs << fmt::format("add_edge source: {}, target: {}", Botan::hex_encode(rhs.source), Botan::hex_encode(rhs.target));
}


struct remove_edge {
    node_id source;
    node_id target;
    MSGPACK_DEFINE_MAP(source, target);

    template<typename Service>
    auto operator()(Service& svc) const {
        return svc.remove_edge(source, target);
    }

    static std::string command_name() { return "remove_edge"; }
};

inline
std::ostream& operator<<(std::ostream& lhs, const remove_edge& rhs) {
    return lhs << fmt::format("remove_edge source: {}, target: {}", Botan::hex_encode(rhs.source), Botan::hex_encode(rhs.target));
}


struct set_edge_attribute {
    node_id source;
    node_id target;
    attr_id key;
    attr_value value;
    MSGPACK_DEFINE_MAP(source, target, key, value);
    template<typename Service>
    auto operator()(Service& svc) const {
        return svc.set_edge_attribute(source, target, key, value);
    }
    static std::string command_name() { return "set_edge_attribute"; }
};

inline
std::ostream& operator<<(std::ostream& lhs, const set_edge_attribute& rhs) {
    return lhs << fmt::format("set_edge_attribute source: {}, target: {} key: {} value:{}", Botan::hex_encode(rhs.source), Botan::hex_encode(rhs.target), rhs.key, Botan::hex_encode(rhs.value));
}

struct clear_edge_attribute {
    node_id source;
    node_id target;
    attr_id key;
    MSGPACK_DEFINE_MAP(source, target, key);
    template<typename Service>
    auto operator()(Service& svc) const {
        return svc.clear_edge_attribute(source, target, key);
    }

    static std::string command_name() { return "clear_edge_attribute"; }
};

inline
std::ostream& operator<<(std::ostream& lhs, const clear_edge_attribute& rhs) {
    return lhs << fmt::format("clear_edge_attribute source: {}, target: {} key: {}", Botan::hex_encode(rhs.source), Botan::hex_encode(rhs.target), rhs.key);
}

struct get_edge_attribute {
    node_id source;
    node_id target;
    attr_id key;
    MSGPACK_DEFINE_MAP(source, target, key);
    template<typename Service>
    auto operator()(Service& svc) const {
        return svc.get_edge_attribute(source, target, key);
    }

    static std::string command_name() { return "get_edge_attribute"; }
};

inline
std::ostream& operator<<(std::ostream& lhs, const get_edge_attribute& rhs) {
    return lhs << fmt::format("get_edge_attribute source: {}, target: {} key: {}", Botan::hex_encode(rhs.source), Botan::hex_encode(rhs.target), rhs.key);
}

struct set_node_attribute {
    node_id id;
    attr_id key;
    attr_value value;
    MSGPACK_DEFINE_MAP(id, key, value);

    template<typename Service>
    auto operator()(Service& svc) const {
        return svc.set_node_attribute(id, key, value);
    }

    static std::string command_name() { return "set_node_attribute"; }

};

inline
std::ostream& operator<<(std::ostream& lhs, const set_node_attribute& rhs) {
    return lhs << fmt::format("set_node_attribute node: {}, key: {} value:{}", Botan::hex_encode(rhs.id), rhs.key, Botan::hex_encode(rhs.value));
}

struct clear_node_attribute {
    node_id id;
    attr_id key;
    MSGPACK_DEFINE_MAP(id, key);

    template<typename Service>
    auto operator()(Service& svc) const {
        return svc.clear_node_attribute(id, key);
    }

    static std::string command_name() { return "clear_node_attribute"; }
};

inline
std::ostream& operator<<(std::ostream& lhs, const clear_node_attribute& rhs) {
    return lhs << fmt::format("clear_node_attribute node: {}, key: {}", Botan::hex_encode(rhs.id), rhs.key);
}

struct get_node_attribute {
    node_id     id;
    attr_id     key;
    MSGPACK_DEFINE_MAP(id, key);

    template<typename Service>
    auto operator()(Service& svc) const {
        return svc.get_node_attribute(id, key);
    }

    static std::string command_name() { return "get_node_attribute"; }
};

inline
std::ostream& operator<<(std::ostream& lhs, const get_node_attribute& rhs) {
    return lhs << fmt::format("get_node_attribute node: {} key: {}", Botan::hex_encode(rhs.id), rhs.key);
}

struct list_inedges {
    node_id id;
    MSGPACK_DEFINE_MAP(id);

    template<typename Service>
    auto operator()(Service& svc) const {
        return svc.list_inedges(id);
    }

    static std::string command_name() { return "list_inedges"; }
};

inline
std::ostream& operator<<(std::ostream& lhs, const list_inedges& rhs) {
    return lhs << fmt::format("list_inedges node: {}", Botan::hex_encode(rhs.id));
}


struct list_outedges {
    node_id id;
    MSGPACK_DEFINE_MAP(id);

    template<typename Service>
    auto operator()(Service& svc) const {
        return svc.list_outedges(id);
    }

    static std::string command_name() { return "list_outedges"; }
};

inline
std::ostream& operator<<(std::ostream& lhs, const list_outedges& rhs) {
    return lhs << fmt::format("list_outedges node: {}", Botan::hex_encode(rhs.id));
}

struct list_nodes {
    std::optional<int> _;
    MSGPACK_DEFINE_MAP(_);
    template<typename Service>
    auto operator()(Service& svc) const {
        return svc.list_nodes();
    }

    static std::string command_name() { return "list_nodes"; }
};

inline
std::ostream& operator<<(std::ostream& lhs, const list_nodes& rhs) {
    return lhs << list_nodes::command_name();
}

} // namespace morpheus::osg::proto
