#pragma once

// thirdparty
#include <spdlog/fmt/ostr.h>
#include <spdlog/fmt/fmt.h>

// std
#include <cstdint>
#include <iostream>

namespace morpheus::osg::proto {

enum class error_code : uint8_t {
    ok                  = 0,
    key_not_found       = 1,
    key_already_exists  = 2,
    attribute_not_found = 3,
    source_not_found    = 4,
    target_not_found    = 5,
    internal_server_error = 6,
};

inline
std::ostream& operator<<(std::ostream& lhs, const error_code& rhs) {
    switch(rhs) {
        case error_code::ok : return lhs << "ok";
        case error_code::key_not_found : return lhs << "key not found";
        case error_code::key_already_exists : return lhs << "key already exists";
        case error_code::attribute_not_found : return lhs << "attribute not found";
        case error_code::source_not_found : return lhs << "source not found";
        case error_code::target_not_found : return lhs << "target not found";
        case error_code::internal_server_error : return lhs << "internal server error";
    }

    std::terminate();
}


} // namespace morpheus::osg::proto
