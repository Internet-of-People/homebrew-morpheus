#pragma once

// ours

// thirdparty
#include <msgpack.hpp>

// std
#include <cstdint>
#include <vector>
#include <string>
#include <map>

namespace morpheus::osg::proto {

using request_id = uint64_t;
using node_id = std::vector<uint8_t>;
using attr_id = std::string;
using attr_value = std::vector<uint8_t>;
using attrs = std::map<attr_id, attr_value>;


// for database storage
struct edge_id {
    edge_id() = default;
    edge_id(node_id source, node_id target) :
        source(std::move(source)),
        target(std::move(target))
    {}

    node_id source;
    node_id target;

    MSGPACK_DEFINE_ARRAY(source, target);
};

} // namespace morpheus::osg::proto
