#pragma once

// ours
#include "commands.hpp"
#include <morpheus/msgpack_helpers.hpp>

// thirdparty
#include <spdlog/fmt/fmt.h>
#include <msgpack.hpp>

// std
#include <iostream>
#include <variant>
#include <functional>

namespace morpheus::osg::proto {

using inner_request = std::variant<add_node,
                                    remove_node,
                                    add_edge,
                                    remove_edge,
                                    list_inedges,
                                    list_outedges,
                                    list_nodes,
                                    set_edge_attribute,
                                    clear_edge_attribute,
                                    get_edge_attribute,
                                    set_node_attribute,
                                    clear_node_attribute,
                                    get_node_attribute>;

struct request {
    request_id rid;
    inner_request inner;
};

inline
std::ostream& operator<<(std::ostream& lhs, const request& rhs) {
    return lhs << fmt::format("request_id: {} request: {}", rhs.rid, std::visit([&](const auto& ir) {return fmt::format("{}", ir); }, rhs.inner));
}

} // namespace morpheus::osg::proto


namespace msgpack {
MSGPACK_API_VERSION_NAMESPACE(MSGPACK_DEFAULT_API_NS) {
namespace adaptor {

template<typename T>
struct req_map;

template<typename ...Args>
struct req_map<std::variant<Args...>> {
    using variant_type = std::variant<Args...>;
    using requests_type = std::map<std::string, std::function<variant_type(const msgpack::object&)>>;
    static const requests_type& get() {
        static requests_type retval = init();
        return retval;
    }
private:
    static requests_type init() {
        requests_type retval;
        init_impl<Args...>(retval);
        return retval;
    }

    template<typename T>
    static void init_impl(requests_type& v) {
        v[T::command_name()] = [](const msgpack::object& obj) -> variant_type {
            return obj.as<T>();
        };
    }

    template<typename T1, typename T2, typename ...Args1>
    static void init_impl(requests_type& v) {
        init_impl<T1>(v);
        init_impl<T2, Args1...>(v);
    }
};

// Some type trait helpers (will be part of c++20)
template< class T >
struct remove_cvref {
    typedef std::remove_cv_t<std::remove_reference_t<T>> type;
};

template< class T >
using remove_cvref_t = typename remove_cvref<T>::type;

template<>
struct convert<morpheus::osg::proto::request> {
    msgpack::object const& operator()(msgpack::object const& o, morpheus::osg::proto::request& v) const {
        if (o.type != msgpack::type::MAP) throw msgpack::parse_error("map type expected");
        using namespace morpheus::osg::proto;

        std::optional<request_id> rid;
        std::optional<std::string> method;
        std::optional<msgpack::object> params;

        for(decltype(o.via.map.size) idx = 0; idx < o.via.map.size; ++idx) {
            msgpack::object_kv& kv = o.via.map.ptr[idx];

            if (morpheus::msgp::try_fetch_field("rid", kv, rid) ||
                morpheus::msgp::try_fetch_field("method", kv, method) ||
                morpheus::msgp::try_fetch_field("params", kv, params)) {
                if (rid && method && params) {
                    v.rid = *rid;
                    auto request_map = req_map<morpheus::osg::proto::inner_request>::get();
                    if (auto it = request_map.find(*method);it != request_map.end()) {
                        v.inner = it->second(*params);
                        return o;
                    }


                    throw msgpack::parse_error(fmt::format("invalid method '{}'", *method));
                }
            }
        }

        throw msgpack::parse_error("incomplete request, required fields are missing");
    }
};

template<>
struct pack<morpheus::osg::proto::request> {
    template <typename Stream>
    packer<Stream>& operator()(msgpack::packer<Stream>& o, const morpheus::osg::proto::request& v) const {
        o.pack_map(3);
        o.pack("rid");
        o.pack(v.rid);
        std::visit(
            [&](const auto& inner) {
               o.pack("method");
               o.pack(remove_cvref_t<decltype(inner)>::command_name());
               o.pack("params");
               o.pack(inner);
            },
        v.inner);
        return o;
    }
};

} // namespace msgpack
} // namespace MSGPACK_DEFAULT_API_NS
} // namespace adaptor
