#pragma once

// ours
#include "primitives.hpp"
#include "error_code.hpp"
#include "result.hpp"

// thirdparty
#include <spdlog/fmt/fmt.h>
#include <msgpack.hpp>

// std
#include <vector>
#include <cstdint>
#include <optional>
#include <string>


namespace morpheus::osg::proto {

template<typename T>
struct response {
    response() = default;
    response(request_id rid, const T& reply, error_code ec = error_code::ok, const std::optional<std::string>& message = std::nullopt) :
        rid(rid),
        code(static_cast<uint8_t>(ec)),
        description(message),
        reply(reply)
    {}
    response(request_id rid, error_code ec, const std::optional<std::string>& message = std::nullopt) :
        rid(rid),
        code(static_cast<uint8_t>(ec)),
        description(message)
    {}

    request_id                  rid;
    uint8_t                     code;
    std::optional<std::string>  description;
    std::optional<T>            reply;
    MSGPACK_DEFINE_MAP(rid, code, description, reply);
};

template<>
struct response<void> {
    response(request_id rid, const result& res) :
        rid(rid),
        code(static_cast<uint8_t>(res.code)),
        description(res.msg)
    {}

    request_id                  rid;
    uint8_t                     code;
    std::optional<std::string>  description;
    MSGPACK_DEFINE_MAP(rid, code, description);
};

template<typename T>
std::vector<uint8_t> to_payload(const response<T>& r) {
    std::vector<uint8_t> retval;
    msgp::vector_buffer_adapter buf(retval);
    msgpack::pack(buf, r);
    return retval;
}

template<typename T>
std::ostream& operator<<(std::ostream& lhs, const response<T>& rhs) {
    lhs << fmt::format("request_id: {} code: {}", rhs.rid, rhs.code);
    if (rhs.description) {
        lhs << fmt::format(" message: '{}'", *rhs.description);
    }

    // lhs << fmt::format(" reply: '{}'", rhs.reply);
    return lhs;
}

std::ostream& operator<<(std::ostream& lhs, const response<void>& rhs) {
    lhs << fmt::format("request_id: {} code: {}", rhs.rid, rhs.code);
    if (rhs.description) {
        lhs << fmt::format(" message: '{}'", *rhs.description);
    }
    return lhs;
}


} // morpheus::osg::proto
