#pragma once

// ours
#include "error_code.hpp"

// thirdparty
#include <spdlog/fmt/fmt.h>

// std
#include <optional>

namespace morpheus::osg::proto {

struct result {
    result(error_code code = error_code::ok) :
        code(code)
    {}

    result(error_code code, const std::string& msg) :
        code(code),
        msg(msg)
    {}

    template<typename ...Args>
    result(error_code code, const char* fmtstr, Args&& ...args) :
        code(code),
        msg(fmt::format(fmtstr, std::forward<Args>(args)...))
    {}

    explicit operator bool() const {
        return code != error_code::ok;
    }

    error_code code;
    std::optional<std::string> msg;
};

inline
std::ostream& operator<<(std::ostream& lhs, const result& rhs) {
    if (rhs.msg) {
        lhs << fmt::format("{}: ", *rhs.msg);
    }

    return lhs << fmt::format("{} ({})", rhs.code, static_cast<uint8_t>(rhs.code));
}

} // namespace morpheus::osg::proto
