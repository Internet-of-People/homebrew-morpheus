#pragma once

// ours
#include "handler.hpp"
#include "proto.hpp"

#include <morpheus/message.hpp>
#include <morpheus/logger.hpp>
#include <morpheus/handler.hpp>
#include <morpheus/service.hpp>
#include <morpheus/overloaded.hpp>
#include <morpheus/rocksdb_helpers.hpp>
#include <morpheus/database.hpp>


// thirdparty
#include <rocksdb/db.h>
#include <spdlog/fmt/fmt.h>
#include <asio/io_service.hpp>

// std
#include <deque>
#include <string>
#include <system_error>
#include <thread>
#include <mutex>

namespace morpheus {
namespace rdb {
template<>
struct from_slice_impl<::morpheus::osg::proto::attrs> {
    ::morpheus::osg::proto::attrs operator()(const rocksdb::PinnableSlice& src) const {
         msgpack::object_handle result;
         unpack(result, src.data(), src.size());
         msgpack::object obj(result.get());
         return obj.as<::morpheus::osg::proto::attrs>();
    }
};
} // namespace rdb

namespace osg {

inline
std::string handler_name() {
    return "osg";
}

template<typename MUX>
class service : public morpheus::service<MUX> {
public:
    service(const std::string& db_path, log_level verbosity) :
        morpheus::service<MUX>(handler_name()),
        log(make_log(this->id(), verbosity)),
        db(db_path)
    {
        log->info("database opened at '{}'", db_path);
    }

    virtual handler_ref<MUX> attach(std::shared_ptr<MUX> m) override {
        log->debug("creating handler to {}", m->name());
        auto retval = std::make_unique<handler<service>>(*this, m, log->level());
        return retval;
    }

    proto::result add_node(proto::node_id id) {
        if (db.load(column_family::nodes, id)) {
            return proto::error_code::key_already_exists;
        }

        // value
        db.store(column_family::nodes, id, proto::attrs{});
        return proto::error_code::ok;
    }

    proto::result remove_node(proto::node_id id) {
        if (! db.load(column_family::nodes, id)) {
            return proto::error_code::key_not_found;
        }

        auto outedges_status = list_outedges(id);
        auto visit_outedge_err = std::visit(overloaded{
            [&](const proto::result &res) { return res; },
            [&](const std::vector<proto::node_id> &outedges_vec) {
                for (proto::node_id peer_id : outedges_vec) {
                    log->trace("cascade deleting outgoing edge {} of node {}", Botan::hex_encode(peer_id), Botan::hex_encode(id));
                    auto remove_err = remove_edge(id, peer_id);
                    if (remove_err)
                        { return remove_err; }
                }
                return proto::result(proto::error_code::ok);
            }
        }, outedges_status);
        if (visit_outedge_err)
            { return visit_outedge_err; }

        // value
        db.remove(column_family::nodes, id);
        return proto::error_code::ok;
    }

    proto::result add_edge(proto::node_id source, proto::node_id target) {
        if (!db.load(column_family::nodes, source)) {
            return proto::result(proto::error_code::key_not_found, "source '{}' not found", Botan::hex_encode(source));
        }

        if (!db.load(column_family::nodes, target)) {
            return proto::result(proto::error_code::key_not_found, "target '{}' not found", Botan::hex_encode(source));
        }

        proto::edge_id eid(source, target);
        if (db.load(column_family::edges, eid)) {
            return proto::error_code::key_already_exists;
        }

        db.store(column_family::edges, eid, proto::attrs{});
        return proto::error_code::ok;
    }

    proto::result remove_edge(proto::node_id source, proto::node_id target) {
        proto::edge_id eid(source, target);
        if (! db.load(column_family::edges, eid)) {
            return proto::result(proto::error_code::key_not_found);
        }

        db.remove(column_family::edges, eid);
        return proto::error_code::ok;
    }

    proto::result set_edge_attribute(const proto::node_id& source, const proto::node_id& target, const proto::attr_id& key, const proto::attr_value& value) {
        proto::edge_id eid(source, target);
        std::optional<rdb::value> val = db.load(column_family::edges, eid);
        if (!val) {
            return proto::error_code::key_not_found;
        }

        auto edge_val = val->as<proto::attrs>();
        edge_val[key] = value;
        db.store(column_family::edges, eid, edge_val);
        return proto::error_code::ok;
    }

    std::variant<proto::result, proto::attr_value> get_edge_attribute(const proto::node_id& source, const proto::node_id& target, const proto::attr_id& key) {
        proto::edge_id eid(source, target);
        std::optional<rdb::value> val = db.load(column_family::edges, eid);
        if (!val) {
            return proto::result(proto::error_code::key_not_found, "edge '{}' -> '{}' not found", Botan::hex_encode(source), Botan::hex_encode(target));
        }

        auto attrs = val->as<proto::attrs>();
        auto it = attrs.find(key);
        if (it == attrs.end()) {
            return proto::result(proto::error_code::attribute_not_found, "attribute '{}' not found", key);
        }

        return it->second;

    }

    proto::result clear_edge_attribute(const proto::node_id& source, const proto::node_id& target, const std::string& key) {
        proto::edge_id eid(source, target);
        std::optional<rdb::value> val = db.load(column_family::edges, eid);
        if (!val) {
            return proto::result(proto::error_code::key_not_found, "edge '{}' -> '{}' not found", Botan::hex_encode(source), Botan::hex_encode(target));
        }

        auto attrs = val->as<proto::attrs>();
        auto it = attrs.find(key);
        if (it == attrs.end()) {
            return proto::result(proto::error_code::attribute_not_found, "attribute '{}' not found", key);
        }
        attrs.erase(it);
        db.store(column_family::edges, eid, attrs);

        return proto::error_code::ok;
    }


    proto::result set_node_attribute(const proto::node_id& id, const proto::attr_id& key, const proto::attr_value& value) {
        std::optional<rdb::value> val = db.load(column_family::nodes, id);
        if (!val) {
            return proto::result(proto::error_code::key_not_found, "node '{}' not found", Botan::hex_encode(id));
        }

        auto attrs = val->as<proto::attrs>();
        attrs[key] = value;
        db.store(column_family::nodes, id, attrs);
        return proto::error_code::ok;
    }

    std::variant<proto::result, proto::attr_value> get_node_attribute(const proto::node_id& id, const proto::attr_id& key) {
        std::optional<rdb::value> val = db.load(column_family::nodes, id);
        if (!val) {
            return proto::result(proto::error_code::key_not_found, "node '{}' not found", Botan::hex_encode(id));
        }

        auto attrs = val->as<proto::attrs>();
        auto it = attrs.find(key);
        if (it == attrs.end()) {
            return proto::result(proto::error_code::attribute_not_found, "attribute '{}' not found", key);
        }

        return it->second;
    }

    proto::result clear_node_attribute(const proto::node_id& id, const std::string& key) {
        std::optional<rdb::value> val = db.load(column_family::edges, id);
        if (!val) {
            return proto::result(proto::error_code::key_not_found, "node '{}' not found", Botan::hex_encode(id));
        }

        auto attrs = val->as<proto::attrs>();
        auto it = attrs.find(key);
        if (it == attrs.end()) {
            return proto::result(proto::error_code::attribute_not_found, "attribute '{}' not found", key);
        }
        attrs.erase(it);
        db.store(column_family::edges, id, attrs);

        return proto::error_code::ok;
    }

    std::variant<proto::result, std::vector<proto::node_id>> list_inedges(proto::node_id id) {
        std::optional<rdb::value> val = db.load(column_family::nodes, id);
        if (!val) {
            return proto::result(proto::error_code::key_not_found, "node '{}' not found", Botan::hex_encode(id));
        }

        std::vector<proto::node_id> retval;
        rocksdb::ReadOptions ro;
        auto it = rdb::iterator_handle(db.connection().NewIterator(ro, db[column_family::edges]));
        for(it->SeekToFirst(); it->Valid(); it->Next()) {
            rocksdb::Slice key_buf = it->key();
            msgpack::object_handle oh;
            std::size_t off = 0;
            msgpack::unpack(oh, key_buf.data(), key_buf.size(), off);
            proto::edge_id eid = oh.get().as<proto::edge_id>();
            if (eid.target == id) {
                retval.push_back(eid.source);
            }
        }

        return retval;
    }

    std::variant<proto::result, std::vector<proto::node_id>> list_outedges(proto::node_id id) {
        std::optional<rdb::value> val = db.load(column_family::nodes, id);
        if (!val) {
            return proto::result(proto::error_code::key_not_found, "node '{}' not found", Botan::hex_encode(id));
        }

        std::vector<proto::node_id> retval;
        rocksdb::ReadOptions ro;
        auto it = rdb::iterator_handle(db.connection().NewIterator(ro, db[column_family::edges]));
        for(it->SeekToFirst(); it->Valid(); it->Next()) {
            rocksdb::Slice key_buf = it->key();
            msgpack::object_handle oh;
            std::size_t off = 0;
            msgpack::unpack(oh, key_buf.data(), key_buf.size(), off);
            proto::edge_id eid = oh.get().as<proto::edge_id>();
            if (eid.source == id) {
                retval.push_back(eid.target);
            }
        }

        return retval;
    }

    std::variant<proto::result, std::vector<proto::node_id>> list_nodes() {
        std::vector<proto::node_id> retval;
        rocksdb::ReadOptions ro;
        auto it = rdb::iterator_handle(db.connection().NewIterator(ro, db[column_family::nodes]));
        for(it->SeekToFirst(); it->Valid(); it->Next()) {
            auto p = reinterpret_cast<const uint8_t*>(it->key().data());
            retval.push_back( proto::node_id{ p , p+it->key().size() } );
// NOTE node ids are currently stored as naked bytes, not serialized as msgpack
//            rocksdb::Slice key_buf = it->key();
//            msgpack::object_handle oh;
//            std::size_t off = 0;
//            std::cout << "Key size: " << key_buf.size() << std::endl;
//            msgpack::unpack(oh, key_buf.data(), key_buf.size(), off);
//            auto nid = oh.get().as<proto::node_id>();
//            retval.push_back(nid);
        }

        return retval;
    }
private:
    asio::io_service                            io;
    log_handle                                  log;

    morpheus::database                          db;
};

} // namespace osg
} // namespace morpheus
