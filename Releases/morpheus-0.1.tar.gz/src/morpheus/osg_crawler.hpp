#pragma once

// ours
#include <morpheus/client.hpp>
#include <morpheus/osg/proto.hpp>
#include <morpheus/overloaded.hpp>

// thirdparty
#include <asio/ip/tcp.hpp>
#include <asio/io_service.hpp>
#include <msgpack.hpp>

#include <spdlog/fmt/fmt.h>
#include <spdlog/fmt/ostr.h>

#include <botan-2/botan/hex.h>

#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/fruchterman_reingold.hpp>
#include <boost/graph/random_layout.hpp>
#include <boost/graph/point_traits.hpp>

// std
#include <string>
#include <variant>
#include <functional>
#include <cstdint>
#include <system_error>


enum vertex_position_t { vertex_position };
namespace boost { BOOST_INSTALL_PROPERTY(vertex, position); }

namespace morpheus {

typedef boost::cube_topology<>::point_type point;

typedef boost::adjacency_list<boost::listS, boost::listS, boost::undirectedS,
                       // Vertex properties
                       boost::property<boost::vertex_index_t, int,
                       boost::property<vertex_position_t, point,
                       boost::property<boost::vertex_name_t, std::string> > >,
                       // Edge properties
                       boost::property<boost::edge_weight_t, double> > social_graph;

using vertex_type = boost::graph_traits<social_graph>::vertex_descriptor;


class osg_crawler {
private:
    enum class state {
        init,
        resolving,
        connecting,
        fetching_nodes,
        fetching_edges
    };
public:
    osg_crawler(asio::io_service& io, const std::string& addr, uint16_t port, morpheus::log_level verbosity) :
        io(io),
        addr(addr),
        port(port),
        resolv(io),
        sock(io),
        log(morpheus::make_log("osg_crawler", verbosity)),
        s(state::init),
        last_rid(0)
    {}

    using result = std::variant<std::error_code, social_graph>;
    using completion_handler = std::function<void(const result&)>;

    void async_extract(completion_handler cb) {
        if (s != state::init) {
            return post(cb, make_error_code(std::errc::operation_in_progress));
        }

        this->cb = cb;

        set_state(state::resolving);
    }

private:
    static std::string osg_service_id() {
        const static std::string retval = "osg";
        return retval;
    }

    osg::proto::request_id next_rid() {
        return ++last_rid;
    }

    void start_resolve() {
        resolv.async_resolve(addr, std::to_string(port), [this](const std::error_code& ec, auto it) {
            if (ec) {
                log->error("address resolution failed");
                return complete(ec);
            }

            ep = *it;
            log->info("connecting to {}", ep);
            set_state(state::connecting);
        });
    }

    void start_connect() {
        sock.async_connect(ep, [this] (const std::error_code& ec) {
            if (ec) {
                log->error("connect failed");
                return complete(ec);
            }
            set_state(state::fetching_nodes);
        });
    }

    void start_fetch_nodes() {
        cli.emplace(io, sock, log->level());

        osg::proto::request req;
        req.rid = next_rid();
        req.inner = osg::proto::list_nodes{};
        cli->async_request(osg_service_id(), req, [this](const osg_client::response& resp) {
            std::visit(overloaded{
                [this](const std::error_code& ec) {
                    complete(ec);
                },
                [this](const std::vector<uint8_t>& r) {
                    try {
                        msgpack::object_handle oh = msgpack::unpack(reinterpret_cast<const char*>(r.data()), r.size());
                        auto rn = oh.get().as<osg::proto::response<std::vector<osg::proto::node_id>>>();
                        log->debug("fetched {} nodes", rn.reply->size());
                        std::move(rn.reply->begin(), rn.reply->end(), std::back_inserter(nodes_to_visit));
                        graph.emplace();
                        for(auto&& nid : nodes_to_visit) {
                            node_map.emplace(nid, boost::add_vertex(*graph));
                        }

                        set_state(state::fetching_edges);
                    } catch (const std::exception& ex) {
                        log->error("failed to process list_nodes response: {}", ex.what());
                        complete(make_error_code(std::errc::bad_message));
                    }
                }
            }, resp);
        });
    }

    void start_fetching_edges() {
        if (nodes_to_visit.empty()) {
            return complete(*graph);
        }

        osg::proto::request req;
        req.rid = next_rid();
        req.inner = osg::proto::list_outedges{nodes_to_visit.front()};
        log->info("visiting node: {}", Botan::hex_encode(nodes_to_visit.front()));

        cli->async_request(osg_service_id(), req, [this] (const osg_client::response& resp) {
            std::visit(overloaded{
                [this](const std::error_code& ec) {
                    complete(ec);
                },
                [this](const std::vector<uint8_t>& r) {
                    try {
                        msgpack::object_handle oh = msgpack::unpack(reinterpret_cast<const char*>(r.data()), r.size());
                        auto rn = oh.get().as<osg::proto::response<std::vector<osg::proto::node_id>>>();
                        log->debug("fetched {} edges", rn.reply->size());
                        auto source = node_map.at(nodes_to_visit.front());
                        for(auto&& tid : *rn.reply) {
                            auto edge = boost::add_edge(source, node_map.at(tid), *graph).first;
                            boost::put(boost::edge_weight, *graph, edge, 1.0);
                        }
                        // rinse&repeat
                        nodes_to_visit.pop_front();
                        start_fetching_edges();

                    } catch (const std::exception& ex) {
                        log->error("failed to process list_nodes response: {}", ex.what());
                        complete(make_error_code(std::errc::bad_message));
                    }
                }
            }, resp);

        });
    }

    void set_state(state new_state) {
        s = new_state;
        switch(s) {
            case state::init :
                cli = std::nullopt;
                graph = std::nullopt;
                nodes_to_visit.clear();
                sock.close();
                ep = endpoint();
                node_map.clear();
                return;
            case state::resolving :
                return start_resolve();
            case state::connecting :
                return start_connect();
            case state::fetching_nodes :
                return start_fetch_nodes();
            case state::fetching_edges :
                return start_fetching_edges();
        }
    }

    void post(completion_handler cb, const result& res) {
        io.post(std::bind(cb, res));
    }

    void complete(const result& res) {
        if (auto ocb = std::exchange(cb, std::nullopt)) {
            set_state(state::init);
            post(*ocb, res);
        }
    }
private:
    using protocol = asio::ip::tcp;
    using socket = protocol::socket;
    using resolver = protocol::resolver;
    using endpoint = protocol::endpoint;
    using osg_client = client<socket>;
private:
    asio::io_service&                   io;
    std::string                         addr;
    uint16_t                            port;
    resolver                            resolv;
    endpoint                            ep;
    socket                              sock;
    std::optional<osg_client>           cli;
    std::optional<completion_handler>   cb;
    std::optional<social_graph>         graph;
    morpheus::log_handle                log;
    state                               s;

    //std::deque<osg::proto::request>     tx_queue;
    std::deque<osg::proto::node_id>     nodes_to_visit;
    std::map<osg::proto::node_id, vertex_type> node_map;
    osg::proto::request_id              last_rid;
};

} // namespace morpheus
