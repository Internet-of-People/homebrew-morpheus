#pragma once

// ours

// thirdparty
#include <asio/ip/tcp.hpp>

// std
#include <cstdint>

namespace morpheus {

static constexpr uint16_t default_port = 6161;

using service_id = std::string;
using session_id = uint64_t;
using request_id = uint64_t;

using proto = asio::ip::tcp;
using acceptor = proto::acceptor;
using socket = proto::socket;
using endpoint = proto::endpoint;

} // namespace morpheus
