#pragma once

#include <morpheus/msgpack_helpers.hpp>
#include <rocksdb/db.h>

#include <string>
#include <vector>
#include <cstdint>

namespace morpheus {
namespace rdb {

struct db_handle_deleter {
    void operator()(rocksdb::DB* ptr) const {
        if (ptr) {
            delete ptr;
        }
    }
};

using db_handle = std::unique_ptr<rocksdb::DB, db_handle_deleter>;

struct iterator_handle_deleter {
    void operator()(rocksdb::Iterator* ptr) {
        if (ptr) {
            delete ptr;
        }
    }
};

using iterator_handle = std::unique_ptr<rocksdb::Iterator, iterator_handle_deleter>;

inline
::rocksdb::Slice to_slice(const std::vector<uint8_t>& v) {
    ::rocksdb::Slice retval(reinterpret_cast<const char*>(v.data()), v.size());
    return retval;
}

inline
::rocksdb::Slice to_slice(const std::string& v) {
    return ::rocksdb::Slice(v);
}

struct owned_slice {
public:
    template<typename T>
    owned_slice(const T& value) {
        morpheus::msgp::vector_buffer_adapter b(buf);
        msgpack::pack(b, value);
    }

    operator rocksdb::Slice() {
        return rocksdb::Slice(reinterpret_cast<char*>(buf.data()), buf.size());
    }
private:
    std::vector<uint8_t> buf;
};

template<typename T>
owned_slice to_slice(const T& v) {
    return owned_slice(v);
}

template<typename T>
struct from_slice_impl {
    T operator()(const ::rocksdb::PinnableSlice& src) const;
};

template<>
struct from_slice_impl<std::vector<uint8_t>> {
    std::vector<uint8_t> operator()(const rocksdb::PinnableSlice& src) const {
        auto ptr = reinterpret_cast<const uint8_t*>(src.data());
        return std::vector<uint8_t>(ptr, ptr + src.size());
    }
};

template<typename T>
T from_slice(const ::rocksdb::PinnableSlice& src) {
    return from_slice_impl<T>{}(src);
}

template<typename T, typename Q>
void store(rocksdb::DB& db, rocksdb::ColumnFamilyHandle* cfh, const T& key, const Q& val) {
    auto status = db.Put(rocksdb::WriteOptions(), cfh, to_slice(key), to_slice(val));
    if (!status.ok()) {
        throw std::runtime_error(fmt::format("failed to store key: {}", status.ToString()));
    }
}

template<typename T>
void remove(rocksdb::DB& db, rocksdb::ColumnFamilyHandle* cfh, const T& key) {
    auto status = db.Delete(rocksdb::WriteOptions(), cfh, to_slice(key));
    if (!status.ok()) {
        throw std::runtime_error(fmt::format("failed to remove key: {}", status.ToString()));
    }
}

class value {
public:
    value() :
        handle(std::make_unique<rocksdb::PinnableSlice>())
    {}

    value(value&& ) = default;
    value& operator=(value&&) = default;

    explicit operator bool() const {
        return !handle->empty();
    }

    operator rocksdb::PinnableSlice*() {
        return handle.get();
    }

    template<typename T>
    std::optional<T> as_opt() const {
        if (*this) {
            return from_slice<T>(*handle);
        }

        return std::nullopt;
    }

    template<typename T>
    T as() const {
        if (*this) {
            return from_slice<T>(*handle);
        }

        throw std::bad_cast{};
    }
private:
    using pinnable_slice_handle = std::unique_ptr<rocksdb::PinnableSlice>;
private:
    pinnable_slice_handle handle;
};


template<typename T>
std::optional<value> load(rocksdb::DB& db, rocksdb::ColumnFamilyHandle* cfh, const T& key) {
    value result;
    auto status = db.Get(rocksdb::ReadOptions(), cfh, to_slice(key), result);

    if (!status.ok()) {
        if (status.IsNotFound()) {
            return std::nullopt;
        } else
        throw std::runtime_error(fmt::format("failed to load key: {}", status.ToString()));
    }

    std::optional<value> retval;
    retval.emplace(std::move(result));
    return retval;
}

} // rdb
} // morpheus
