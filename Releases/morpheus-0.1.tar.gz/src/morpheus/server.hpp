#pragma once

// ours
#include "proto.hpp"
#include "logger.hpp"
#include "mux.hpp"
#include "service.hpp"

// thirdparty
#include <spdlog/spdlog.h>
#include <spdlog/sinks/stdout_color_sinks.h>


#include <asio/io_service.hpp>

#include <functional>
#include <optional>
#include <system_error>
#include <map>

namespace morpheus {

///
/// \brief The server class
///
class server {

public:
    using completion_handler = std::function<void(const std::error_code& ec)>;

    server(asio::io_service& io,
           endpoint ep,
           log_level verbosity) :
        last_session_id(0),
        log(make_log(fmt::format("server@{}", ep), verbosity)),
        io(io),
        listener(io, ep),
        incoming(io)
    {
        log->info("server initialized");
    }

    void async_wait(completion_handler handler) {
        if (this->cb) {
            return post(handler, make_error_code(std::errc::operation_in_progress));
        }

        this->cb = handler;

        start_listen();
    }

    void cancel() {
        listener.cancel();
        for(auto&& s : sessions) {
            s.second->cancel();
        }
    }

    template<template <typename> typename Service, typename ...Args>
    void register_service(Args&& ...args) {
        auto svc = std::make_unique<Service<mux>>(std::forward<Args>(args)...);
        services.emplace(svc->id(), std::move(svc));
    }

private:
    void start_listen() {
        listener.async_accept(incoming, incoming_ep, [this](const std::error_code& ec) {
            if (ec) {
                log->error("failed to accept incoming connection: {} ({})", ec.message(), ec);
                return complete(ec);
            }

            // creating a new session
            log->info("incoming connection from {}", incoming_ep);
            auto sid = ++last_session_id;

            if (auto [iter, success] = sessions.emplace(sid, std::make_shared<mux>(sid, std::exchange(incoming, socket(io)), log->level()));success) {
                auto m = iter->second;
                for(auto&& svch : services) {
                    log->trace("registering session {} with {} handler", sid, svch.first);
                    // attaching the service on the session
                    handler_ref<mux> h = svch.second->attach(m);
                    // the handler should be stored in the mux
                    m->add_handler(svch.first, std::move(h));
                }

                m->async_wait([this, sid](const std::error_code& ec){
                    log->log(ec ? log_level::warn : log_level::info, "session terminated: {} ({})", ec.message(), ec);
                    sessions.erase(sid);
                });

            }


            start_listen();
        });
    }

    void post(completion_handler handler, const std::error_code& ec) {
        io.post(std::bind(handler, ec));
    }

    void complete(const std::error_code& ec) {
        if (auto ocb = std::exchange(cb, std::nullopt)) {
            post(*ocb, ec);
        }
    }
private:
    using mux_handle = std::shared_ptr<mux>;
    using mux_map = std::map<session_id, mux_handle>;
    using service_map = std::map<service_id, service_handle<mux>>;
private:
    std::optional<completion_handler>   cb;

    session_id                          last_session_id;
    log_handle                          log;
    asio::io_service&                   io;
    endpoint                            listen_ep;
    acceptor                            listener;
    socket                              incoming;
    endpoint                            incoming_ep;

    mux_map                             sessions;
    service_map                         services;
};


} // namespace morpheus
