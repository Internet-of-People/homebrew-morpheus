#pragma once

#include "proto.hpp"
#include "handler.hpp"

namespace morpheus {

///
/// \brief The service class
///
/// Instances of this class are registered at the server. When a new session is created at the server,
/// it asks the corresponding service (determined by the string id) to create a handler instance to manage
/// messaging towards that service.
///
/// Services are integrating this template as a CRTP-style base class.
///
/// Eg.: a minimal implementation of a service looks like
///
/// template<typename MUX>
/// class my_service : public service<my_service> {
/// public:
///     virtual handler_ref<MUX> attach(std::shared_ptr<MUX> m) override { ... }
/// };
///

template<typename MUX>
class service {
public:
    using mux_type = MUX;
    service(service_id id) :
        _id(id)
    {}

    service_id id() const {
        return _id;
    }

    virtual handler_ref<MUX> attach(std::shared_ptr<MUX> sess) = 0;

    virtual ~service() = default;
private:
    service_id  _id;
};

template<typename MUX>
using service_handle = std::unique_ptr<service<MUX>>;

} // namespace morpheus
