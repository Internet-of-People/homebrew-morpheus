#pragma once

// ours
#include "handler.hpp"
#include "proto.hpp"
#include <morpheus/handler.hpp>

// thirdparty
#include <spdlog/spdlog.h>
#include <spdlog/fmt/fmt.h>


// std
#include <memory>
#include <system_error>

namespace morpheus::vis {

template<typename Service>
class handler : public morpheus::handler<typename Service::mux_type> {
public:
    using service_type = Service;
    using mux_type = typename Service::mux_type;

    handler(service_type& svc, std::shared_ptr<mux_type> m, log_level verbosity) :
        morpheus::handler<mux_type>(svc.id(), m),
        svc(svc),
        log(make_log(fmt::format("{}@{}", svc.id(), m->name()), verbosity))
    {}

    virtual std::error_code on_message(const message &msg) override {
        msgpack::object_handle oh = msgpack::unpack((char*)msg.payload.data(), msg.payload.size());
        try {
            process_message(oh.get().as<proto::request>());
            return std::error_code{};
        } catch (const std::system_error& ex) {
            log->error("failed to process message '{}': {}", oh.get(), ex.what());
            return ex.code();
        } catch (const std::exception& ex) {
            log->error("failed to process message '{}': {}", oh.get(), ex.what());
            return make_error_code(std::errc::invalid_argument);
        } catch (...) {
            log->error("failed to process message '{}'", oh.get());
            return make_error_code(std::errc::invalid_argument);
        }
    }
private:
    void process_message(const proto::request& req) {
        // log->debug(">>> {}", req);
        // std::visit([&](const auto& inner) { reply(req.rid, inner(svc)); }, req.inner);
    }
private:
    Service&                    svc;
    log_handle                  log;
};

} // namespace morpheus::vis
