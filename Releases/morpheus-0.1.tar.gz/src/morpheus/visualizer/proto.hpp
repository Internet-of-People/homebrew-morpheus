#pragma once

#include <msgpack.hpp>

namespace morpheus::vis::proto {

struct request {
    int foo;
    MSGPACK_DEFINE_MAP(foo);
};

struct response {
    int foo;
    MSGPACK_DEFINE_MAP(foo);
};


} // namespace morpheus::vis
