#pragma once

// ours
#include "handler.hpp"
#include <morpheus/service.hpp>

// std
#include <string>

namespace morpheus::vis {

inline
std::string handler_name() {
    return "osg";
}

template<typename MUX>
class service : public morpheus::service<MUX> {
public:
    service(const std::string& db_path, log_level verbosity) :
        morpheus::service<MUX>(handler_name()),
        log(make_log(this->id(), verbosity)),
        db(db_path, morpheus::database::default_ro_options())
    {
        log->info("database opened at '{}'", db_path);
    }

    virtual handler_ref<MUX> attach(std::shared_ptr<MUX> m) {
        log->debug("creating handler to {}", m->name());
        auto retval = std::make_unique<handler<service>>(*this, m, log->level());
        return retval;
    }
private:
    asio::io_service                            io;
    log_handle                                  log;

    morpheus::database                          db;
};

} // namespace morpheus::vis
