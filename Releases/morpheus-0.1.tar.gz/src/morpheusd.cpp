// our
#include "morpheus/server.hpp"
#include "morpheus/proto.hpp"
#include "morpheus/osg/service.hpp"
#include "morpheus/visualizer/service.hpp"

// thirdparty
#include <spdlog/spdlog.h>
#include <spdlog/sinks/stdout_color_sinks.h>
#include <spdlog/fmt/ostr.h>


#include <CLI11.hpp>
#include <asio.hpp>
#include <asio/io_service.hpp>
#include <asio/signal_set.hpp>

// std
#include <sysexits.h>

int main(int argc, char* argv[]) {
    // parsing arguments
    CLI::App app{"morpheus storage daemon"};    
    std::string loglevel = "info";
    std::string listen_address = "0.0.0.0";
    std::string dbpath;
    uint16_t listen_port = morpheus::default_port;
    std::optional<std::string> config_file;

    app.add_option("--database", dbpath, "database path")->default_val("/tmp/morpheus.db");
    app.add_option("--loglevel", loglevel, "log verbosity (trace, debug, info, warn, error, critical, off)")->default_val("info");
    app.add_option("--address", listen_address, "address to bind to");
    app.add_option("--port", listen_port, "port to bind to");
    app.add_option("--config-file", config_file, "config file");

    CLI11_PARSE(app, argc, argv);

    // set up logging
    auto llevel = spdlog::level::from_str(loglevel);
    std::shared_ptr<spdlog::logger> log = spdlog::stdout_color_mt("morpheusd");
    log->set_level(llevel);

    // wiring up server
    asio::io_service io;

    morpheus::endpoint ep(asio::ip::address::from_string(listen_address), listen_port);
    morpheus::server server(io, ep, llevel);
    server.register_service<morpheus::osg::service>(dbpath, llevel);
    // server.register_service<morpheus::vis::service>(dbpath, llevel);

    auto sigs = std::make_unique<asio::signal_set>(io, SIGINT, SIGHUP);
    sigs->async_wait([&](const std::error_code& ec, int signo) {
        if (ec) {
            log->error("signal handler failed, stopping application: {} ({})", ec.message(), ec);
        } else {
            log->warn("stopping on signal SIG{}", signo);
        }

        server.cancel();
    });

    server.async_wait([&](const std::error_code& ec) {
        log->warn("server stopped with {} ({})", ec.message(), ec);
        sigs.reset();
    });

    // let it go
    try {
        log->debug("starting event loop");
        io.run();
        log->debug("event loop stopped");
    } catch (const std::exception& ex) {
        log->error("unexpected failure: {}", ex.what());
        return EX_SOFTWARE;
    } catch (...) {
        log->critical("unexpected failure");
        return EX_SOFTWARE;
    }

	return 0;
}
