#pragma once

#define MAJOR_VERSION 1
#define MINOR_VERSION 0
#define SUB_VERSION 0
