// ours
#include <morpheus/overloaded.hpp>
#include <morpheus/osg_crawler.hpp>

// thirdparty


#include <spdlog/fmt/fmt.h>
#include <spdlog/fmt/ostr.h>

#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/fruchterman_reingold.hpp>
#include <boost/graph/random_layout.hpp>
#include <boost/graph/point_traits.hpp>

#include <osg/Geode>
#include <osg/ShapeDrawable>
#include <osgViewer/Viewer>
// #include <osgViewer/ViewerEventHandlers>
// #include <osg/LightSource>

// std
#include <fstream>

using namespace boost;

void  draw_edge(osg::Vec3 start, osg::Vec3 end, float radius, osg::Vec4 color, osg::Group* owner)  {
    osg::Vec3 center;
    float height;

   osg::ref_ptr<osg::Cylinder> cylinder;
   osg::ref_ptr<osg::ShapeDrawable> cylinderDrawable;
   osg::ref_ptr<osg::Geode> geode;

   height = (start- end).length();
   center = osg::Vec3( (start.x() + end.x()) / 2,  (start.y() + end.y()) / 2,  (start.z() + end.z()) / 2);

   // This is the default direction for the cylinders to face in OpenGL
   osg::Vec3   z = osg::Vec3(0,0,1);

   // Get diff between two points you want cylinder along
   osg::Vec3 p = (start - end);

   // Get CROSS product (the axis of rotation)
   osg::Vec3   t = z ^  p;

   // Get angle. length is magnitude of the vector
   double angle = acos( (z * p) / p.length());

   //   Create a cylinder between the two points with the given radius
   cylinder = new osg::Cylinder(center,radius,height);
   cylinder->setRotation(osg::Quat(angle, osg::Vec3(t.x(), t.y(), t.z())));

   //   A geode to hold our cylinder
   geode = new osg::Geode;
   cylinderDrawable = new osg::ShapeDrawable(cylinder );
   cylinderDrawable->setColor(color);
   geode->addDrawable(cylinderDrawable);

   //   Add the cylinder between the two points to an existing group
   owner->addChild(geode);
}



int main(int argc, char* argv[]) {
    auto verbosity = morpheus::log_level::debug;
    std::string host = "127.0.0.1";
    uint16_t port = 6161;

    auto log = morpheus::make_log("main", spdlog::level::debug);
    asio::io_service io;
    std::optional<morpheus::social_graph> oosg;
    morpheus::osg_crawler crawler(io, host, port, verbosity);
    crawler.async_extract([&](const morpheus::osg_crawler::result& res) {
        std::visit(morpheus::overloaded{
            [&](const morpheus::social_graph& g) {
                log->info("extractor completed, commencing visualization");
                oosg.emplace(g);
            },
            [&](const std::error_code& ec) {
                log->error("extractor failed with {}", ec.message());
            }
        }, res);
    });
    io.run();

    if (oosg) {
        auto& osg = *oosg;
        cube_topology topology{};
        random_graph_layout(osg, get(vertex_position, osg), topology);


        log->info("generating layout");
        std::vector<cube_topology<>::point_difference_type> displacements(num_vertices(osg));
        fruchterman_reingold_force_directed_layout(osg,
                                                   get(vertex_position, osg),
                                                   topology,
                                                   square_distance_attractive_force(),
                                                   square_distance_repulsive_force(),
                                                   all_force_pairs(), linear_cooling<double>(100),
                                                   make_iterator_property_map(displacements.begin(), get(vertex_index, osg), cube_topology<>::point_difference_type()));

        // construct the viewer.
        osgViewer::Viewer viewer;

        osg::ref_ptr<osg::Geode> root = new osg::Geode;
        auto position = get(vertex_position, osg);

        auto [vi, vi_end] = vertices(osg);
        log->info("processing {} vertices", std::distance(vi, vi_end));
        for (; vi != vi_end; ++vi) {
            osg::ref_ptr<osg::ShapeDrawable> shape = new osg::ShapeDrawable;
            auto red = osg::Vec4(1.0f, 0.0f, 0.0f, 1.0f);
            auto pos = osg::Vec3(position[*vi][0], position[*vi][1], position[*vi][2]);
            auto radius = 0.001f;
            shape->setShape(new osg::Sphere(pos, radius));
            shape->setColor(red);
            root->addChild(shape);
        }

        auto [ei, ei_end] = edges(osg);
        log->info("processing {} edges", std::distance(ei, ei_end));
        for (; ei != ei_end; ++ei) {
            auto source = boost::source(*ei, osg);
            auto source_pos = osg::Vec3(position[source][0], position[source][1], position[source][2]);
            auto target = boost::target(*ei, osg);
            auto target_pos = osg::Vec3(position[target][0], position[target][1], position[target][2]);
            auto radius = 0.0003f;
            auto blue = osg::Vec4(0.0f, 1.0f, 0.0f, 1.0f);
            draw_edge(source_pos, target_pos, radius, blue, root.get());
        }

        log->info("starting visualization");
        viewer.setSceneData(root.get());
        return viewer.run();
    }
    return -1;
}



